import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/foundation.dart';

Future initFirebase() async {
  if (kIsWeb) {
    await Firebase.initializeApp(
        options: FirebaseOptions(
            apiKey: "AIzaSyB2RL35c6stdppzIAXU7DBYypQ3TNhAe4A",
            authDomain: "fluttterapp-a2e1e.firebaseapp.com",
            projectId: "fluttterapp-a2e1e",
            storageBucket: "fluttterapp-a2e1e.firebasestorage.app",
            messagingSenderId: "18531252231",
            appId: "1:18531252231:web:2d5391efa4ed6c1dc492a2"));
  } else {
    await Firebase.initializeApp();
  }
}
