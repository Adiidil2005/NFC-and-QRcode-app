import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class ProductDataRecord extends FirestoreRecord {
  ProductDataRecord._(
    DocumentReference reference,
    Map<String, dynamic> data,
  ) : super(reference, data) {
    _initializeFields();
  }

  // "Address" field.
  String? _address;
  String get address => _address ?? '';
  bool hasAddress() => _address != null;

  // "District" field.
  String? _district;
  String get district => _district ?? '';
  bool hasDistrict() => _district != null;

  // "Pin_no" field.
  int? _pinNo;
  int get pinNo => _pinNo ?? 0;
  bool hasPinNo() => _pinNo != null;

  // "Price_rs" field.
  int? _priceRs;
  int get priceRs => _priceRs ?? 0;
  bool hasPriceRs() => _priceRs != null;

  // "Product_ID" field.
  int? _productID;
  int get productID => _productID ?? 0;
  bool hasProductID() => _productID != null;

  // "Product_name" field.
  String? _productName;
  String get productName => _productName ?? '';
  bool hasProductName() => _productName != null;

  // "Quantity" field.
  int? _quantity;
  int get quantity => _quantity ?? 0;
  bool hasQuantity() => _quantity != null;

  // "Reciver_name" field.
  String? _reciverName;
  String get reciverName => _reciverName ?? '';
  bool hasReciverName() => _reciverName != null;

  // "State" field.
  String? _state;
  String get state => _state ?? '';
  bool hasState() => _state != null;

  void _initializeFields() {
    _address = snapshotData['Address'] as String?;
    _district = snapshotData['District'] as String?;
    _pinNo = castToType<int>(snapshotData['Pin_no']);
    _priceRs = castToType<int>(snapshotData['Price_rs']);
    _productID = castToType<int>(snapshotData['Product_ID']);
    _productName = snapshotData['Product_name'] as String?;
    _quantity = castToType<int>(snapshotData['Quantity']);
    _reciverName = snapshotData['Reciver_name'] as String?;
    _state = snapshotData['State'] as String?;
  }

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('Product_data');

  static Stream<ProductDataRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => ProductDataRecord.fromSnapshot(s));

  static Future<ProductDataRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => ProductDataRecord.fromSnapshot(s));

  static ProductDataRecord fromSnapshot(DocumentSnapshot snapshot) =>
      ProductDataRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static ProductDataRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      ProductDataRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'ProductDataRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is ProductDataRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createProductDataRecordData({
  String? address,
  String? district,
  int? pinNo,
  int? priceRs,
  int? productID,
  String? productName,
  int? quantity,
  String? reciverName,
  String? state,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'Address': address,
      'District': district,
      'Pin_no': pinNo,
      'Price_rs': priceRs,
      'Product_ID': productID,
      'Product_name': productName,
      'Quantity': quantity,
      'Reciver_name': reciverName,
      'State': state,
    }.withoutNulls,
  );

  return firestoreData;
}

class ProductDataRecordDocumentEquality implements Equality<ProductDataRecord> {
  const ProductDataRecordDocumentEquality();

  @override
  bool equals(ProductDataRecord? e1, ProductDataRecord? e2) {
    return e1?.address == e2?.address &&
        e1?.district == e2?.district &&
        e1?.pinNo == e2?.pinNo &&
        e1?.priceRs == e2?.priceRs &&
        e1?.productID == e2?.productID &&
        e1?.productName == e2?.productName &&
        e1?.quantity == e2?.quantity &&
        e1?.reciverName == e2?.reciverName &&
        e1?.state == e2?.state;
  }

  @override
  int hash(ProductDataRecord? e) => const ListEquality().hash([
        e?.address,
        e?.district,
        e?.pinNo,
        e?.priceRs,
        e?.productID,
        e?.productName,
        e?.quantity,
        e?.reciverName,
        e?.state
      ]);

  @override
  bool isValidKey(Object? o) => o is ProductDataRecord;
}
