import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class TimeRecord extends FirestoreRecord {
  TimeRecord._(
    DocumentReference reference,
    Map<String, dynamic> data,
  ) : super(reference, data) {
    _initializeFields();
  }

  // "del_time" field.
  String? _delTime;
  String get delTime => _delTime ?? '';
  bool hasDelTime() => _delTime != null;

  void _initializeFields() {
    _delTime = snapshotData['del_time'] as String?;
  }

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('Time');

  static Stream<TimeRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => TimeRecord.fromSnapshot(s));

  static Future<TimeRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => TimeRecord.fromSnapshot(s));

  static TimeRecord fromSnapshot(DocumentSnapshot snapshot) => TimeRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static TimeRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      TimeRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'TimeRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is TimeRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createTimeRecordData({
  String? delTime,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'del_time': delTime,
    }.withoutNulls,
  );

  return firestoreData;
}

class TimeRecordDocumentEquality implements Equality<TimeRecord> {
  const TimeRecordDocumentEquality();

  @override
  bool equals(TimeRecord? e1, TimeRecord? e2) {
    return e1?.delTime == e2?.delTime;
  }

  @override
  int hash(TimeRecord? e) => const ListEquality().hash([e?.delTime]);

  @override
  bool isValidKey(Object? o) => o is TimeRecord;
}
