// Export pages
export '/pages/home_page/home_page_widget.dart' show HomePageWidget;
export '/q_r_scan/q_r_scan_widget.dart' show QRScanWidget;
export '/q_r_success/q_r_success_widget.dart' show QRSuccessWidget;
export '/q_r_details/q_r_details_widget.dart' show QRDetailsWidget;
export '/r_f_i_d_scan/r_f_i_d_scan_widget.dart' show RFIDScanWidget;
export '/data_write/data_write_widget.dart' show DataWriteWidget;
export '/rfid_success/rfid_success_widget.dart' show RfidSuccessWidget;
export '/rfid_details/rfid_details_widget.dart' show RfidDetailsWidget;
export '/scanvault_verify/scanvault_verify_widget.dart'
    show ScanvaultVerifyWidget;
export '/all_product_details/all_product_details_widget.dart'
    show AllProductDetailsWidget;
export '/product_gen/product_gen_widget.dart' show ProductGenWidget;
export '/n_f_c_write/n_f_c_write_widget.dart' show NFCWriteWidget;
export '/scanvault_login_copy/scanvault_login_copy_widget.dart'
    show ScanvaultLoginCopyWidget;
export '/update_product/update_product_widget.dart' show UpdateProductWidget;
