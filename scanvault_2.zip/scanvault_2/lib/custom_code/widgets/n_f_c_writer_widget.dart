// Automatic FlutterFlow imports
import '/backend/backend.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'index.dart'; // Imports other custom widgets
import 'package:flutter/material.dart';
// Begin custom widget code
// DO NOT REMOVE OR MODIFY THE CODE ABOVE!

// Set your widget name, define your parameter, and then add the
// boilerplate code using the green button on the right!
import 'package:nfc_manager/nfc_manager.dart';

import 'package:nfc_manager/nfc_manager.dart';

class NFCWriterWidget extends StatefulWidget {
  final double? width;
  final double? height;

  // QR data parameters
  final String reciverName;
  final String prodName;
  final int pinNo;
  final int prodID;
  final int price;
  final int quantity;
  final String address;
  final String district;
  final String state;

  const NFCWriterWidget({
    Key? key,
    this.width,
    this.height,
    required this.reciverName,
    required this.prodName,
    required this.pinNo,
    required this.prodID,
    required this.price,
    required this.quantity,
    required this.address,
    required this.district,
    required this.state,
  }) : super(key: key);

  @override
  State<NFCWriterWidget> createState() => _NFCWriterWidgetState();
}

class _NFCWriterWidgetState extends State<NFCWriterWidget> {
  Future<void> _writeToNFC() async {
    String data = '''
    {
      "reciver_name": "${widget.reciverName}",
      "prod_name": "${widget.prodName}",
      "pin_no": "${widget.pinNo}",
      "prod_ID": "${widget.prodID}",
      "price": "${widget.price}",
      "quantity": "${widget.quantity}",
      "address": "${widget.address}",
      "district": "${widget.district}",
      "state": "${widget.state}"
    }
    ''';

    try {
      bool isAvailable = await NfcManager.instance.isAvailable();
      if (isAvailable) {
        NfcManager.instance.startSession(onDiscovered: (NfcTag tag) async {
          try {
            NdefMessage message = NdefMessage([NdefRecord.createText(data)]);
            await Ndef.from(tag)?.write(message);

            ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(content: Text('Data written successfully: $data')),
            );
            NfcManager.instance.stopSession();
          } catch (e) {
            ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(content: Text('Error writing NFC data: $e')),
            );
          }
        });
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('NFC not available.')),
        );
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('NFC writing error: $e')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      width: widget.width ?? 200,
      height: widget.height ?? 100,
      child: ElevatedButton(
        onPressed: _writeToNFC,
        child: const Text('Write NFC Data'),
      ),
    );
  }
}
