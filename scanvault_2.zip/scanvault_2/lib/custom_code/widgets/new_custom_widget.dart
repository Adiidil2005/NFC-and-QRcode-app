// Automatic FlutterFlow imports
import '/backend/backend.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'index.dart'; // Imports other custom widgets
import 'package:flutter/material.dart';
// Begin custom widget code
// DO NOT REMOVE OR MODIFY THE CODE ABOVE!

import 'package:nfc_manager/nfc_manager.dart';

class NewCustomWidget extends StatefulWidget {
  const NewCustomWidget({
    Key? key,
    this.width, // Width parameter for FlutterFlow
    this.height, // Height parameter for FlutterFlow
  }) : super(key: key);

  final double? width; // Optional width parameter
  final double? height; // Optional height parameter

  @override
  State<NewCustomWidget> createState() => _NewCustomWidgetState();
}

class _NewCustomWidgetState extends State<NewCustomWidget> {
  void _startNFCReading(BuildContext context) async {
    try {
      bool isAvailable = await NfcManager.instance.isAvailable();

      // Check if NFC is available on the device
      if (isAvailable) {
        // Start NFC session and listen for NFC tags to be discovered
        NfcManager.instance.startSession(
          onDiscovered: (NfcTag tag) async {
            // Display the NFC tag data in a Snackbar
            ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(
                content: Text('NFC Tag Detected: ${tag.data}'),
              ),
            );
            debugPrint('NFC Tag Detected: ${tag.data}');
          },
        );
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('NFC not available on this device.'),
          ),
        );
        debugPrint('NFC not available.');
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Error reading NFC: $e'),
        ),
      );
      debugPrint('Error reading NFC: $e');
    }
  }

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width:
          widget.width ?? double.infinity, // Set width or full width by default
      height: widget.height ?? 50.0, // Set height or default to 50.0
      child: ElevatedButton(
        onPressed: () => _startNFCReading(context),
        child: const Text('Start NFC Reading'),
      ),
    );
  }
}
