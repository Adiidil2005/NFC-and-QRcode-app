// Automatic FlutterFlow imports
import '/backend/backend.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'index.dart'; // Imports other custom widgets
import 'package:flutter/material.dart';
// Begin custom widget code
// DO NOT REMOVE OR MODIFY THE CODE ABOVE!

// Set your widget name, define your parameter, and then add the
// boilerplate code using the green button on the right!
import 'package:qr_flutter/qr_flutter.dart';

class QRCode extends StatefulWidget {
  const QRCode({
    Key? key,
    this.width,
    this.height,
    this.qrSize,
    required this.reciverName,
    required this.prodName,
    required this.pinNo,
    required this.prodID,
    required this.price,
    required this.quantity,
    required this.address,
    required this.district,
    required this.state,
    this.qrBorderRadius,
    this.qrBackgroundColor,
    this.qrForegroundColor,
  }) : super(key: key);

  final double? width;
  final double? height;
  final double? qrSize;

  // Parameters for QR data
  final String reciverName;
  final String prodName;
  final int pinNo;
  final int prodID;
  final int price;
  final int quantity;
  final String address;
  final String district;
  final String state;

  final double? qrBorderRadius;
  final Color? qrBackgroundColor;
  final Color? qrForegroundColor;

  @override
  State<QRCode> createState() => _QRCodeState();
}

class _QRCodeState extends State<QRCode> {
  // Concatenated data in JSON-like format
  String get qrData => '''
  {
    "reciver_name": "${widget.reciverName}",
    "prod_name": "${widget.prodName}",
    "pin_no": "${widget.pinNo.toString()}",
    "prod_ID": "${widget.prodID.toString()}",
    "price": "${widget.price.toString()}",
    "quantity": "${widget.quantity.toString()}",
    "address": "${widget.address}",
    "district": "${widget.district}",
    "state": "${widget.state}"
  }
  ''';

  @override
  Widget build(BuildContext context) {
    return ClipRRect(
      borderRadius: BorderRadius.circular(widget.qrBorderRadius ?? 0),
      child: QrImageView(
        data: qrData,
        size: widget.qrSize ?? 200.0, // Default size if none specified
        backgroundColor: widget.qrBackgroundColor ?? Colors.transparent,
        foregroundColor: widget.qrForegroundColor ?? Colors.black,
      ),
    );
  }
}
