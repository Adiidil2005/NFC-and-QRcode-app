import '/backend/backend.dart';
import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'data_write_widget.dart' show DataWriteWidget;
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class DataWriteModel extends FlutterFlowModel<DataWriteWidget> {
  ///  State fields for stateful widgets in this page.

  // State field(s) for reciver_name widget.
  FocusNode? reciverNameFocusNode;
  TextEditingController? reciverNameTextController;
  String? Function(BuildContext, String?)? reciverNameTextControllerValidator;
  // State field(s) for product_name widget.
  FocusNode? productNameFocusNode;
  TextEditingController? productNameTextController;
  String? Function(BuildContext, String?)? productNameTextControllerValidator;
  // State field(s) for pin_no widget.
  FocusNode? pinNoFocusNode;
  TextEditingController? pinNoTextController;
  String? Function(BuildContext, String?)? pinNoTextControllerValidator;
  // State field(s) for product_id widget.
  FocusNode? productIdFocusNode;
  TextEditingController? productIdTextController;
  String? Function(BuildContext, String?)? productIdTextControllerValidator;
  // State field(s) for price widget.
  FocusNode? priceFocusNode;
  TextEditingController? priceTextController;
  String? Function(BuildContext, String?)? priceTextControllerValidator;
  // State field(s) for quantity widget.
  FocusNode? quantityFocusNode;
  TextEditingController? quantityTextController;
  String? Function(BuildContext, String?)? quantityTextControllerValidator;
  // State field(s) for address widget.
  FocusNode? addressFocusNode;
  TextEditingController? addressTextController;
  String? Function(BuildContext, String?)? addressTextControllerValidator;
  // State field(s) for district widget.
  FocusNode? districtFocusNode;
  TextEditingController? districtTextController;
  String? Function(BuildContext, String?)? districtTextControllerValidator;
  // State field(s) for state widget.
  FocusNode? stateFocusNode;
  TextEditingController? stateTextController;
  String? Function(BuildContext, String?)? stateTextControllerValidator;

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {
    reciverNameFocusNode?.dispose();
    reciverNameTextController?.dispose();

    productNameFocusNode?.dispose();
    productNameTextController?.dispose();

    pinNoFocusNode?.dispose();
    pinNoTextController?.dispose();

    productIdFocusNode?.dispose();
    productIdTextController?.dispose();

    priceFocusNode?.dispose();
    priceTextController?.dispose();

    quantityFocusNode?.dispose();
    quantityTextController?.dispose();

    addressFocusNode?.dispose();
    addressTextController?.dispose();

    districtFocusNode?.dispose();
    districtTextController?.dispose();

    stateFocusNode?.dispose();
    stateTextController?.dispose();
  }
}
