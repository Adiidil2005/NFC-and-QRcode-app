import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import '/custom_code/widgets/index.dart' as custom_widgets;
import 'r_f_i_d_scan_widget.dart' show RFIDScanWidget;
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class RFIDScanModel extends FlutterFlowModel<RFIDScanWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
